package org.iis.parser;

public interface Symbol {
    String getSymbol();
}
